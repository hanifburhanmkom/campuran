<?php

define ('THEME_NAME',   'Sahifa' );
define ('THEME_FOLDER', 'sahifa' );
define ('THEME_VER',    '5.7.1'  );	//DB Theme Version

define( 'NOTIFIER_XML_FILE',      "http://themes.tielabs.com/xml/".THEME_FOLDER.".xml" );
define( 'NOTIFIER_CHANGELOG_URL', "http://tielabs.com/changelogs/?id=2819356" );
define( 'DOCUMENTATION_URL',      "http://themes.tielabs.com/docs/".THEME_FOLDER );

if ( ! isset( $content_width ) ) $content_width = 618;

// Main Functions
require_once ( get_template_directory() . '/framework/functions/theme-functions.php');
require_once ( get_template_directory() . '/framework/functions/common-scripts.php' );
require_once ( get_template_directory() . '/framework/functions/mega-menus.php'     );
require_once ( get_template_directory() . '/framework/functions/pagenavi.php'       );
require_once ( get_template_directory() . '/framework/functions/breadcrumbs.php'    );
require_once ( get_template_directory() . '/framework/functions/tie-views.php'      );
require_once ( get_template_directory() . '/framework/functions/translation.php'    );
require_once ( get_template_directory() . '/framework/widgets.php'                  );
require_once ( get_template_directory() . '/framework/admin/framework-admin.php'    );
require_once ( get_template_directory() . '/framework/shortcodes/shortcodes.php'    );

if( tie_get_option( 'live_search' ) )
	require_once ( get_template_directory() . '/framework/functions/search-live.php');

if( !tie_get_option( 'disable_arqam_lite' ) )
	require_once ( get_template_directory() . '/framework/functions/arqam-lite.php');



/* WPCOVID-19 */
if( ! class_exists( 'WPCOVID19_CLASS' ) ){
	add_action( 'admin_menu',    'tie_wpcv_add_admin' );
	add_action( 'admin_notices', 'tie_wpcovid_notice' );
}

function tie_wpcovid_notice() {
	?>

	<style type="text/css">
		#toplevel_page_panel ul li:last-child a{
			background: #FF4939 !important;
			color: #fff !important;
		}
	</style>

	<?php
	$id = 'wpcovid19-notice';
	$dismissed_notices = explode( ',', get_user_meta( get_current_user_id(), 'dismissed_wp_pointers', true ));

	if( ! current_user_can( 'manage_options' ) || in_array( $id, $dismissed_notices) ){
		return;
	}

	$class = 'notice is-dismissible';

	$message = '<a target="_blank" href="https://wpcovid19.com/?utm_campaign=tielabs&utm_medium=themes&utm_source=sahifa"><img src="https://tielabs.com/wp-content/uploads/2017/05/wpcovid-19-icon.gif" class="tie-notice-img" alt=""></a>';
	$message .= '<h3>'. __( 'YOUR SUPPORT GOES TO THE PEOPLE!' ) .'</h3>';

	$message .= '<p>Use the new <strong>WPCOVID-19</strong> plugin to display Coronavirus real-time data on your website, choose from a lot of customizable options cards, tables, charts, and maps.</p>';
	$message .= '<p>We in TieLabs will <strong>GIVE AWAY</strong> all the profit to the affected people and communities, Use <strong>SAHIFA</strong> discount code during checkout and <strong>save 15% off</strong> your purchase.</p>';
	$message .= '<a class="button button-primary" target="_blank" href="https://wpcovid19.com/?utm_campaign=tielabs&utm_medium=themes&utm_source=sahifa#pricing">GET IT NOW</a>';
	$message .= '<a class="button" target="_blank" href="https://wpcovid19.com/?utm_campaign=tielabs&utm_medium=themes&utm_source=sahifa">Check Features and Demos</a>';
	?>

	<style type="text/css">

		#<?php echo $id ?>{
			padding: 20px;
			max-width: 850px;
			overflow: hidden;
			padding-bottom: 20px;
			border-color: #FF4939;
		}

		#<?php echo $id ?> h3{
			margin-top: 0;
			margin-bottom: 10px
		}

		#<?php echo $id ?> p{
			font-size: 14px;
		}

		#<?php echo $id ?> img{
			margin-right: 20px;
			float: left;
		}

		#<?php echo $id ?> .button{
			margin-right: 10px;
		}

		.rtl #<?php echo $id ?> .button{
			margin-right: 0;
			margin-left: 10px;
		}

		.rtl #<?php echo $id ?> img{
			margin-right: 0;
			margin-left: 20px;
			float: right;
		}
	</style>
	<script type="text/javascript">

		jQuery(document).on('click', '#<?php echo $id; ?> .notice-dismiss', function(){
			var ID = '<?php echo $id ?>';
			if( typeof ID != 'undefined') {
				jQuery.ajax({
					url : ajaxurl,
					type: 'post',
					data: {
						pointer: ID,
						action : 'dismiss-wp-pointer',
					},
				});
			}
		});
	</script>
	<div id="<?php echo $id ?>" class="<?php echo $class ?>" style="">
		<?php echo $message; ?>
	</div>
	<?php
}


function tie_wpcv_add_admin() {
	add_submenu_page( 'panel', __( 'WPCOVID-19', 'tie' ), __( 'WPCOVID-19', 'tie' ) ,'switch_themes', 'tie_wpcv' , 'tie_get_wpcovid');
}
function tie_get_wpcovid(){
	echo "<script type='text/javascript'>window.location='https://wpcovid19.com/?utm_campaign=tielabs&utm_medium=themes&utm_source=sahifa';</script>";
}

